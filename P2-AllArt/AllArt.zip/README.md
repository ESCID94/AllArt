# AllArt

This is a Git repo of the proyect AllArt (*Art) (allart.com):

All rights and ideas belong to AllArt creators and programmers:

#Enrique Salazar del Cid: enrisala@ucm.es
#Carlos Amat Fernández: caramat@ucm.es
#Sara Núñez Sánchez: sanune01@ucm.es
#Cosmin Mihai Dragomir: cosdrago@ucm.es
#Álvaro Antón García: alvant01@ucm.es

* Art is a way of interacting with other people and being able to share and show the world, in a free way, your own creations.

<?php

  require_once __DIR__.'/includes/formLogin.php';

  session_start();
  formularioLogin();
?>
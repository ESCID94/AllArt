<!doctype html>
<html>
    
    <head>
    
        <meta charset="utf-8">
        <title>Documento sin título</title>
        
    </head>
    
    <body>
    
        <form action="pagina_datos_perfiles.php" method="get">
        
            <p>
              <label>Usuario: 
                <input type="text" name="usu">
              </label>
              <br>
              <label>Contraseña: 
                <input type="text" name="con">
              </label>
            </p>
            <p>
              <input type="submit" name="enviando" value="Login">
            </p>
        
        </form>
    
    </body>
    
</html>
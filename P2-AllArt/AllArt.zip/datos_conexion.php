<?php

	$db_host="localhost";
    $db_nombre="estructura";
    $db_usuario="root";
    $db_contra="";

?>
